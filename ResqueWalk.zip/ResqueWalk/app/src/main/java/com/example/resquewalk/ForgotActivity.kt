package com.example.resquewalk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ForgotActivity : AppCompatActivity() {
    private lateinit var txtSign: TextView
    private lateinit var txtLogin: TextView
    private lateinit var txtSubmit: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot)

        txtSign=findViewById(R.id.txtSign)
        txtLogin=findViewById(R.id.txtLogin)
        txtSubmit=findViewById(R.id.txtSubmit)

        txtSign.setOnClickListener {
            val intent = Intent(this@ForgotActivity, SignActivity::class.java)
            startActivity(intent)
        }
        txtSign.setOnClickListener {
            val intent = Intent(this@ForgotActivity, LoginActivity::class.java)
            startActivity(intent)
        }

        txtLogin.setOnClickListener {
            val intent = Intent(this@ForgotActivity, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}