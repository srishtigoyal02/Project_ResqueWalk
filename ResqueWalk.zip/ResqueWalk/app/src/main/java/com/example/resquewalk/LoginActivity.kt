package com.example.resquewalk

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity(){

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var txtLogin: TextView
    private lateinit var txtForgotPassword: TextView
    private lateinit var txtSignUp:TextView
    private lateinit var txtSign:TextView
    private lateinit var txtSkip: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etUsername=findViewById(R.id.etUsername)
        etPassword=findViewById(R.id.etPassword)
        txtLogin=findViewById(R.id.txtLogIn)
        txtForgotPassword=findViewById(R.id.txtForgotPassword)
        txtSignUp=findViewById(R.id.txtSignUp)
        txtSign=findViewById(R.id.txtSign)
        txtSkip=findViewById(R.id.txtSkip)


        txtSign.setOnClickListener {
            val intent = Intent(this@LoginActivity, SignActivity::class.java)
            startActivity(intent)
        }
        txtForgotPassword.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgotActivity::class.java)
            startActivity(intent)
        }

        txtSkip.setOnClickListener {
            val intent = Intent(this@LoginActivity, HomeActivity::class.java)
            startActivity(intent)
        }
        txtLogin.setOnClickListener { allFilled(etUsername,etPassword)
            val intent = Intent(this@LoginActivity, HomeActivity::class.java)
            startActivity(intent)}


    }

    fun allFilled(text: EditText,text2: EditText) {

        if(text.toString().isNotEmpty() && text2.toString().isNotEmpty()) {
        }
            else {
            Toast.makeText(this, "Credentials cannot be Empty", Toast.LENGTH_SHORT).show()
            return

        }
}
    }
